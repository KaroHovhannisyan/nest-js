export interface IToken {
  token: string;
}
