export interface IFile {
  path: string;
}
