export enum RoleType {
  PUBLISHER = 'PUBLISHER',
  ADMIN = 'ADMIN',
}

export enum TOKEN_REASONS {
  RESET_PASSWORD = 'RESET_PASSWORD',
}

export const USER_REPOSITORY: string = "Users";
